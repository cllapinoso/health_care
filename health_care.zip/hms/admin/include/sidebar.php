

<div class="sidebar app-aside" id="sidebar">
				<div class="sidebar-container perfect-scrollbar">

<nav>
  <ul class="main-navigation-menu">
  <center><img src="logo.jpg" alt="logo" style="width: 150px; margin-top: 1em;"></center>
		  <li> <a href="dashboard.php">
							  <div class="item-content">
							    <div class="item-media"> </div>
							    <div class="item-inner">
							      <span class="title"> <em><strong><center>
							      <span style="color: #FFFFFF">HOME</span></strong></em></span></div>
						    </div>
							</a>							 
							</li>
							<li>
								<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
										</div>
										<div class="item-inner"><strong><em><center><span style="color: #FFFFFF">
											MANAGE ACCOUNTS
										</em></strong></div>
									</div>
								</a>
								<ul class="sub-menu">
									
									<li>
								<a href="javascript:void(0)">
                            <div class="item-content">
                              <div class="item-media"> </div>
                              <div class="item-inner">
                                <span class="title"> <em><strong><center>
                                <span style="color: #FFFFFF">Doctors</span></strong></em></span>
                              </div>
                            </div>
                          </a>
								<ul class="sub-menu">
									<li>
										<a href="doctor-specilization.php">
											<span class="title"> Doctor Specialization </span>
										</a>
									</li>
									<li>
										<a href="add-doctor.php">
											<span class="title"> Add Doctor</span>
										</a>
									</li>
									<li>
										<a href="manage-doctors.php">
											<span class="title"> View Doctors </span>
										</a>
									</li>
									
								</ul>
								</li>

				<li>
								<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
										</div>
										<div class="item-inner"><em><strong><center><span style="color: #FFFFFF">Patients Account</strong></em></div>
									</div>
								</a>
								<ul class="sub-menu">
									
									<li>
										<a href="manage-users.php">
											<span class="title"> View Patients Account </span>
										</a>
									</li>
									
								</ul>
								</li>
								<li>
								<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
										</div>
										<div class="item-inner">
											<span class="title"> <em><strong><center><span style="color: #FFFFFF">Patients (Walk-in)</strong></em></span></div>
									</div>
								</a>
								<ul class="sub-menu">
									
									<li>
										<a href="manage-patient.php">
											<span class="title"> View Patients (Walk-in)</span>
										</a>
									</li>
									
								</ul>
								</li>
								</ul>
							</li>
								

<li>
								<a href="appointment-history.php">
									<div class="item-content">
										<div class="item-media">
										</div>
										<div class="item-inner">
											<span class="title"> <strong><em><center><span style="color: #FFFFFF">APPOINTMENT HISTORY</em></strong></span>
										</div>
									</div>
								</a>
							</li>


				<li>
								<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
										</div>
										<div class="item-inner">
											<span class="title"> <strong><em><center><span style="color: #FFFFFF">
												SESSION LOGS
											</em></strong></span></div>
									</div>
								</a>
								<ul class="sub-menu">
									
									<li>
								<a href="doctor-logs.php">
									<div class="item-content">
										<div class="item-media">
										</div>
										<div class="item-inner"><em><strong><center><span style="color: #FFFFFF">Doctor</strong></em></div>
									</div>
								</a>
							</li>		



							<li>
								<a href="user-logs.php">
									<div class="item-content">
										<div class="item-media">
										</div>
										<div class="item-inner">
											<span class="title"> <strong><em><center><span style="color: #FFFFFF">User</em></strong></span>
										</div>
									</div>
								</a>
							</li>						
</li>
									
								</ul>
								</li>



	

				<!-- <li>
								<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
										</div>
										<div class="item-inner"><strong><em><center><span style="color: #FFFFFF">PAGES SETTINGS</em></strong></div>
									</div>
								</a>
								<ul class="sub-menu">
									
									<li>
										<a href="about-us.php">
											<span class="title">About Us </span>
										</a>
									</li>
																	<li>
										<a href="contact.php">
											<span class="title">Contact Us </span>
										</a>
									</li>
								</ul>
							</li> -->




								<!-- <li>
								<a href="patient-search.php">
									<div class="item-content">
										<div class="item-media">
										</div>
										<div class="item-inner">
											<span class="title"> <em><strong><center><span style="color: #FFFFFF">PATIENT SEARCH</strong></em></span>
										</div>
									</div>
								</a>
							</li> -->

							<li> <a href="../../queuing/admin.php">
								<div class="item-content">
								  <div class="item-media"> </div>
								  <div class="item-inner">
								    <span class="title"> <em><strong><center><span style="color: #FFFFFF">QUEUING</strong></em></span>
						          </div>
						    </div>
							</li>
							<li> <a href="reports.php">
								<div class="item-content">
								  <div class="item-media"> </div>
								  <div class="item-inner">
								    <span class="title"> <em><strong><center><span style="color: #FFFFFF">REPORTS</strong></em></span>
						          </div>
						    </div>
							</li>


							<!-- <li> <a href="chatbot/admin/login.php">
								<div class="item-content">
								  <div class="item-media"> </div>
								  <div class="item-inner">
								    <span class="title"> <em><strong><center><span style="color: #FFFFFF">CHATBOT</strong></em></span>
						          </div>
						    </div> </li> -->
							

						</ul>
						
				  </nav>
  </div>
</div>