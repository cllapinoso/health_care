<footer>
				<div class="footer-inner">
					<div align="center">Holy Spirt Health Care Center</div>
					
					</div>
				</div>
			</footer>