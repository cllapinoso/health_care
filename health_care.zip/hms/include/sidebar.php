<div class="sidebar app-aside" id="sidebar">
				<div class="sidebar-container perfect-scrollbar">

<nav>
						
					
						<ul class="main-navigation-menu">
							<center><img src="logo.jpg" alt="logo" style="width: 150px; margin-top: 1em;"></center>
							<li>
								<a href="dashboard.php">
									<div class="item-content">
										<div class="item-media">
									
										</div>
										<div class="item-inner">
											<span class="title"><center>
											  <em><strong>
												  <span style="color: #FFFFFF">DASHBOARD</span></strong></em>
											</center> 
											</span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="appointment-slot.php">
									<div class="item-content">
										<div class="item-media">
						
										</div>
										<div class="item-inner">
											<span class="title"> <center>
											  <strong><em>
												  <span style="color: #FFFFFF">BOOK APPOINTMENT</span></em></strong>
										  </center></span>
										</div>
									</div>
								</a>
							</li>

							<li>
								<a href="appointment-history.php">
									<div class="item-content">
										<div class="item-media">
										
										</div>
										<div class="item-inner"><center>
										  <strong><em>
											  <span style="color: #FFFFFF">PREVIOUS APPOINTMENT</span></em></strong>
										</center></div>
									</div>
								</a>
							</li>

							<li>
									<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
		
										</div>
										<div class="item-inner">
										<span class="title">
											<span style="color: #FFFFFF"><center> <em><strong>PATIENT RECORDS</center></strong></em></span>									    <strong></strong></div>
									</div>
								</a>
								<ul class="sub-menu">
									
									<li>
										<em><a href="dental_records.php">
											<span class="title">
												<span style="color: #FFFFFF">Dental</span>
										</a>
									    </em></li>

									<li>
										<em><a href="family_planning_records.php">
											<span class="title">
												<span style="color: #FFFFFF">Family Planning</span>
										</a>
									    </em></li>

									<li>
										<em><a href="hiv_records.php">
											<span class="title">
												<span style="color: #FFFFFF">HIV Test</span>
										</a>
									    </em></li>

									<li>
										<em><a href="medical_checkup_records.php">
											<span class="title">
												<span style="color: #FFFFFF">Medical Checkup</span>
										</a>
									    </em></li>

									<li>
										<em><a href="prenatal_records.php">
											<span class="title">
												<span style="color: #FFFFFF">Prenatal</span>
										</a>
									    </em></li>
									
								</ul>
								</li>

						</ul>
					
						
					</nav>
					</div>
			</div>