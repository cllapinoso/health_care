<div class="sidebar app-aside" id="sidebar">
				<div class="sidebar-container perfect-scrollbar bg-dark">

<nav>
						

						<ul class="main-navigation-menu">
						<center><img src="logo.jpg" alt="logo" style="width: 150px; margin-top: 1em;"></center>
							<li>
								<a href="dashboard.php">
								<div class="item-content">
										<div class="item-media">
										
										</div>
										<div class="item-inner">
											<span class="title"> <em><center>
											 <span style="color: #FFFFFF"> <strong>HOME</strong>
											</center></em></span>
									</div>
								  </div>
								</a>
							</li>
							

							<li>
								<a href="appointment-history.php">
									<div class="item-content">
										<div class="item-media">
							
										</div>
										<div class="item-inner">
											<span class="title"><center> 
											  <span style="color: #FFFFFF"><em><strong>APPOINTMENT HISTORY </strong></em>
											</center></span>
										</div>
									</div>
								</a>
							</li>
							<li>
									<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
		
										</div>
										<div class="item-inner">
										<span class="title">
											<span style="color: #FFFFFF"><center> <em><strong>PATIENTS </center></strong></em></span>									    <strong></strong></div>
									</div>
								</a>
								<ul class="sub-menu">
									
									<li>
										<em><a href="add-patient.php" target="_blank">
											<span class="title">
												<span style="color: #FFFFFF">Add Patient</span>
										</a>
									    </em></li>
									<li>
										<em><a href="manage-patient.php">
											<span class="title">
												<span style="color: #FFFFFF">Manage Patient </span>
										</a>
									    </em></li>
									
								</ul>
								</li>

							<li>
									<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
		
										</div>
										<div class="item-inner">
										<span class="title">
											<span style="color: #FFFFFF"><center> <em><strong>SERVICES</center></strong></em></span>									    <strong></strong></div>
									</div>
								</a>
								<ul class="sub-menu">
									
								<li>
									<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
		
										</div>
										<div class="item-inner">
										<span class="title">
											<span style="color: #FFFFFF"><center> <em><strong>Prenatal</center></strong></em></span>									    <strong></strong></div>
									</div>
								</a>
								<ul class="sub-menu">
									
									<li>
										<em><a href="prenatal_lab.php">
											<span class="title">
												<span style="color: #FFFFFF">Add Form</span>
										</a>
									    </em></li>
									<li>
										<em><a href="manage-prenatal.php">
											<span class="title">
												<span style="color: #FFFFFF">Manage Form </span>
										</a>
									    </em></li>
									
								</ul>
								</li>

								<li>
									<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
		
										</div>
										<div class="item-inner">
										<span class="title">
											<span style="color: #FFFFFF"><center> <em><strong>Dental</center></strong></em></span>									    <strong></strong></div>
									</div>
								</a>
								<ul class="sub-menu">
									
									<li>
										<em><a href="dental_lab.php">
											<span class="title">
												<span style="color: #FFFFFF">Add Form</span>
										</a>
									    </em></li>
									<li>
										<em><a href="manage-dental.php">
											<span class="title">
												<span style="color: #FFFFFF">Manage Form </span>
										</a>
									    </em></li>
									
								</ul>
								</li>

								<li>
									<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
		
										</div>
										<div class="item-inner">
										<span class="title">
											<span style="color: #FFFFFF"><center> <em><strong>HIV Test</center></strong></em></span>									    <strong></strong></div>
									</div>
								</a>
								<ul class="sub-menu">
									
									<li>
										<em><a href="form_hiv.php">
											<span class="title">
												<span style="color: #FFFFFF">Add Form</span>
										</a>
									    </em></li>
									<li>
										<em><a href="manage-hiv.php">
											<span class="title">
												<span style="color: #FFFFFF">Manage Form </span>
										</a>
									    </em></li>
									
								</ul>
								</li>

								<li>
									<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
		
										</div>
										<div class="item-inner">
										<span class="title">
											<span style="color: #FFFFFF"><center> <em><strong>Medical Check-up</center></strong></em></span>									    <strong></strong></div>
									</div>
								</a>
								<ul class="sub-menu">
									
									<li>
										<em><a href="form_medical_checkup.php">
											<span class="title">
												<span style="color: #FFFFFF">Add Form</span>
										</a>
									    </em></li>
									<li>
										<em><a href="manage-medical-checkup.php">
											<span class="title">
												<span style="color: #FFFFFF">Manage Form </span>
										</a>
									    </em></li>
									
								</ul>
								</li>

								<li>
									<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
		
										</div>
										<div class="item-inner">
										<span class="title">
											<span style="color: #FFFFFF"><center> <em><strong>Family Planning</center></strong></em></span>									    <strong></strong></div>
									</div>
								</a>
								<ul class="sub-menu">
									
									<li>
										<em><a href="form_family_planning.php">
											<span class="title">
												<span style="color: #FFFFFF">Add Form</span>
										</a>
									    </em></li>
									<li>
										<em><a href="manage-family-planning.php">
											<span class="title">
												<span style="color: #FFFFFF">Manage Form </span>
										</a>
									    </em></li>
									
								</ul>
								</li>
									
									
								</ul>
								</li>
<!-- <li>
								        <em><a href="search.php">
									    <div class="item-content">
									      <div class="item-media"> </div>
									      <div class="item-inner"><center>
									       <span style="color: #FFFFFF"> <strong><em>FIND PATIENTS</em></strong>
									      </center></div>
									      </div>
								        </a></em></li> -->
							<li>
								<a href="../../queuing/queue-patient.php">
									<div class="item-content">
										<div class="item-media">
							
										</div>
										<div class="item-inner">
											<span class="title"><center> 
											  <span style="color: #FFFFFF"><em><strong>QUEUEING </strong></em>
											</center></span>
										</div>
									</div>
								</a>
							</li>

						</ul>
		
						
					</nav>
					</div>
			</div>